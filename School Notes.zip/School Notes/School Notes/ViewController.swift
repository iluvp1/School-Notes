//
//  ViewController.swift
//  School Notes
//
//  Created by John Tarroza on 12/9/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


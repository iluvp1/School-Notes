//
//  Constants.swift
//  TuffyNotes
//
//  Created by John Tarroza on 12/10/21.
//

import Foundation

struct Constants {
    struct Storyboard {
        static let homeViewController = "HomeVC"
    }
}
